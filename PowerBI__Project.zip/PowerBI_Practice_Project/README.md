# PowerBI Practice Project (Levels 1 & 2)

Open `PowerBI_Practice_Project.pbip` in Power BI Desktop (recent version; if prompted, enable
Options > Preview features > "Power BI Project (.pbip) save option" and "Store reports using enhanced metadata format (PBIR)").
Data is embedded in the model, so no file paths need fixing. Click Refresh/Apply if asked.

Pages: L1 - Accounts | L1 - Industry & Profitability | L2 - Bank Customers | L2 - Sales | Insights
Model: Bank_Details 1:1 Bank_Details_1_1 / Bank_Details_1_2 (Customer ID, both directions);
Industry 1:* Accounts 1:* Opportunities. Sales_Data is standalone.
Assumptions: Commission = 5% of total profit ([Commission Rate] measure); Profit = profit per unit x quantity;
bank monthly trend uses Date Joined. Data/ holds CSV copies of every table.
Map visuals need Bing Maps enabled in your tenant/Desktop settings.
